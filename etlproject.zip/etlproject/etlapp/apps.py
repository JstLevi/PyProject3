from django.apps import AppConfig


class EtlappConfig(AppConfig):
    name = 'etlapp'
